import React from 'react';
import Chart from "chart.js/auto";
import { Bar } from 'react-chartjs-2';

const HorizontalBarChart = () => {
    const data={
        labels: ["Monday", "Tuesday", "Wednesday"],
        datasets:[ {
            label: "Branch",
            data: [100, 200, 300],
            backgroundColor: "#61DBFB",
        }]
        

       }
    return (
        <div>
            <Bar
               data = {data}
                options={{
                    indexAxis: "y",
                }}
            />
        </div>
    );
};

export default HorizontalBarChart;

import React from 'react';
import Chart from "chart.js/auto";
import HorizontalBarChart from './HorizontalBarChart';

const YourComponent = () => {
    const data = {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        datasets: [
            {
                label: 'Dataset 1',
                data: [65, 59, 80, 81, 56, 55, 40],
                backgroundColor: 'rgb(255, 99, 132)',
            },
            {
                label: 'Dataset 2',
                data: [28, 48, 40, 19, 86, 27, 90],
                backgroundColor: 'rgb(54, 162, 235)',
            },
        ],
    };

    return (
        <div>
            <h1>Your Horizontal Bar Chart</h1>
            <HorizontalBarChart data={data} />
        </div>
    );
};

export default YourComponent;

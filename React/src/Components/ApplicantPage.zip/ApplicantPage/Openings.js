// import React from 'react';
import React, { useState, useEffect } from 'react';

import { json, useNavigate } from 'react-router-dom';
import './OpenigsFeild.css';
import jsdata from './tempJson.json';

function OpeningsToApply() {
    const navigate = useNavigate();

    const [openings, setOpenings] = useState({});
    const [jsonData, setJsonData] = useState(jsdata);



    // var tempJson;
    const [tempJson, settempJson] = useState({});
    const [transformedData, settransformedData] = useState([]);
    // var transformedData;




    useEffect(() => {
        fetchCall()
    }, [])


    const fetchCall = () => {
        fetch('http://localhost:8080/JobVista/ShowAllUpComingOpeningsServlet', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        }).then(resp => resp.json()).then(async data => {
            console.log(data);
            const val = await data;
            console.log(data.Status);

            // console.log(tempJson);
            if (val.Status === 'Success') {
                // setJsonData(data);
                console.log('suc');
                // tempJson = data
                settempJson(val)
                
                    console.log('in func');
                   mapppu(val)
                
                console.log('value',val);
            }


        }).catch(error => {
            console.log('Error fetching data:', error);
            
        });
    }


    // console.log(jsonData)

    const mapppu = (tempJson) => {
        let wholeData = tempJson.Value.map(item => ({
            Department: item.Department.departmentTitle,
            DepartmentId: item.Department.departmentId,
            Organization: item.Organization.orgName,
            OrgId: item.Organization.orgId,
            salaryRange: item.Opening.salaryRange,
            qualification: item.Opening.qualification,
            employmentType: item.Opening.employmentType,
            endDate: item.Opening.endDate,
            openingId: item.Opening.openingId,
            title: item.Opening.description,
            department: item.Opening.departments,
            experience: item.Opening.experience,
            date: item.Opening.startDate
        }));
        settransformedData(wholeData)
    } 
    
    const handleRowClick = (openingId) => {


        const item = transformedData.find(item => item.openingId === openingId);


        navigate(`/Apply/${item.openingId}`, { state: { item } });
    };


    

    return (
        <div className="table">
            <div className="row header">
                <div className="cell">Opening ID</div>
                <div className="cell">Title</div>
                <div className="cell">Department</div>
                <div className="cell">Salary Range</div>
                <div className="cell">Date</div>
                <div className="cell">Qualification</div>
                <div className="cell">Employment Type</div>
            </div>
            {(transformedData != undefined || transformedData != null) && transformedData.map((item) => (
                <div className="row" key={item.openingId} onClick={() => handleRowClick(item.openingId)}>
                    <div className="cell">{item.openingId}</div>
                    <div className="cell">{item.title}</div>
                    <div className="cell">{item.department}</div>
                    <div className="cell">{item.salaryRange}</div>
                    <div className="cell">{item.date}</div>
                    <div className="cell">{item.qualification}</div>
                    <div className="cell">{item.employmentType}</div>
                </div>
            ))}
        </div>
    );
}

export default OpeningsToApply;
